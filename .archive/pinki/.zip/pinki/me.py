import cv2
import numpy as np
from robolab_turtlebot import Turtlebot, detector


def cceck(img):
  mask={}
  img_vec=np.concatenate(img)
  img_w, img_h , _ =img.shape()
  for key in ['r','g','b']:
    ref ={'r': [0,130,80],'g': [120,80,80],'b': [60,80,80]}[key]
    diff={'r': [255,255,80],'g': [120,80,80],'b': [60,80,80]}[key]
    mask[key]=list(map(lambda x: abs(x[0]-ref[0])<diff[0],img_vec))
  print(type(mask['r']))
  r_mask = np.bitwise_or(mask['r'],mask['g'])
  r_mask = np.bitwise_or(r_mask,mask['b'])
  return cv2.imdecode(np.frombuffer(np.reshape(r_mask,(img_w,img_h)),np.uint8),cv2.IMREAD_UNCHANGED)
  

# countours=[r:,g:,b:]

# this function takes in key-value pair of countours for r,g,b values
# draws them on img, and returns pillar rectangles
def drawBoxes(rgb_contours,img=None):
  pill={}
  for key in ['r','g','b']:
    contours=rgb_contours[key]
    border_color={'r':(0,0,255),'g':(0,255,0),'b':(255,0,0)}[key]
    pill[key]=[]
    for contour in contours:
      x,y,w,h = cv2.boundingRect(contour)
      if w*h>5000 and w*3<h and w*9>h:
          pill[key].append((x,y,w,h))
          if type(img)!=None:
            r_img = cv2.drawContours(img,[contour],0,(255,255,255),2)
            r_img = cv2.rectangle(img,(x,y),(x+w,y+h),border_color,2)
          else:
            r_img = None
  return pill,r_img
     
